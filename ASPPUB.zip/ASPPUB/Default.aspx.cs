﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// This web application was created for Accenture by Ohio University MIS4200 Team 13 and cannot be reproduced or recreated without exress consent

public partial class _Default : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
}